"""
Test cases for TCN model loading and verification.

This module tests:
- Model loading from saved file
- Model architecture verification
- Input/output shape validation
- Forward pass functionality
- Model state preservation
"""

import pytest
import torch
import os
from pathlib import Path
import numpy as np
from typing import Dict, Any

from models.tcn_model import TCNModel
from utils.model_utils import load_model_state

class TestTCNModel:
    @pytest.fixture
    def model_path(self) -> Path:
        """Get path to saved model."""
        return Path("test_model_save/tcn_model.pt")
        
    @pytest.fixture
    def model_config(self) -> Dict[str, Any]:
        """Get model configuration."""
        return {
            "input_size": 10,
            "output_size": 1,
            "num_channels": [64, 32, 16],
            "kernel_size": 3,
            "dropout": 0.2
        }
        
    @pytest.fixture
    def sample_input(self) -> torch.Tensor:
        """Create sample input tensor."""
        return torch.randn(32, 10, 100)  # batch_size, input_size, sequence_length
        
    def test_model_file_exists(self, model_path):
        """Test that model file exists."""
        assert model_path.exists(), f"Model file not found at {model_path}"
        
    def test_model_loading(self, model_path, model_config):
        """Test model loading from file."""
        # Create model
        model = TCNModel(**model_config)
        
        # Load state
        state_dict = load_model_state(model_path)
        model.load_state_dict(state_dict)
        
        # Verify model state
        assert model is not None
        assert isinstance(model, TCNModel)
        
    def test_model_architecture(self, model_path, model_config):
        """Test model architecture matches configuration."""
        # Create model
        model = TCNModel(**model_config)
        state_dict = load_model_state(model_path)
        model.load_state_dict(state_dict)
        
        # Verify architecture
        assert model.input_size == model_config["input_size"]
        assert model.output_size == model_config["output_size"]
        assert len(model.channels) == len(model_config["num_channels"])
        assert model.kernel_size == model_config["kernel_size"]
        assert model.dropout == model_config["dropout"]
        
    def test_model_forward_pass(self, model_path, model_config, sample_input):
        """Test model forward pass."""
        # Create and load model
        model = TCNModel(**model_config)
        state_dict = load_model_state(model_path)
        model.load_state_dict(state_dict)
        
        # Forward pass
        output = model(sample_input)
        
        # Verify output
        assert output is not None
        assert isinstance(output, torch.Tensor)
        assert output.shape == (32, 1, 100)  # batch_size, output_size, sequence_length
        
    def test_model_state_preservation(self, model_path, model_config):
        """Test model state preservation after loading."""
        # Create model
        model = TCNModel(**model_config)
        state_dict = load_model_state(model_path)
        model.load_state_dict(state_dict)
        
        # Get state before forward pass
        state_before = {k: v.clone() for k, v in model.state_dict().items()}
        
        # Forward pass
        sample_input = torch.randn(32, 10, 100)
        model(sample_input)
        
        # Get state after forward pass
        state_after = model.state_dict()
        
        # Verify state preservation
        for key in state_before:
            assert torch.allclose(state_before[key], state_after[key])
            
    def test_model_gradient_flow(self, model_path, model_config, sample_input):
        """Test model gradient flow."""
        # Create and load model
        model = TCNModel(**model_config)
        state_dict = load_model_state(model_path)
        model.load_state_dict(state_dict)
        
        # Enable gradient computation
        sample_input.requires_grad = True
        
        # Forward pass
        output = model(sample_input)
        
        # Compute loss
        loss = output.mean()
        
        # Backward pass
        loss.backward()
        
        # Verify gradients
        assert sample_input.grad is not None
        assert not torch.isnan(sample_input.grad).any()
        
    def test_model_device_transfer(self, model_path, model_config):
        """Test model transfer to different devices."""
        # Create and load model
        model = TCNModel(**model_config)
        state_dict = load_model_state(model_path)
        model.load_state_dict(state_dict)
        
        # Test CPU
        model_cpu = model.to("cpu")
        assert next(model_cpu.parameters()).device.type == "cpu"
        
        # Test CUDA if available
        if torch.cuda.is_available():
            model_cuda = model.to("cuda")
            assert next(model_cuda.parameters()).device.type == "cuda"
            
    def test_model_serialization(self, model_path, model_config, tmp_path):
        """Test model serialization and deserialization."""
        # Create and load model
        model = TCNModel(**model_config)
        state_dict = load_model_state(model_path)
        model.load_state_dict(state_dict)
        
        # Save model
        save_path = tmp_path / "model.pt"
        torch.save(model.state_dict(), save_path)
        
        # Load model
        new_model = TCNModel(**model_config)
        new_model.load_state_dict(torch.load(save_path))
        
        # Verify model state
        for p1, p2 in zip(model.parameters(), new_model.parameters()):
            assert torch.allclose(p1, p2)
            
    def test_model_inference_mode(self, model_path, model_config, sample_input):
        """Test model inference mode."""
        # Create and load model
        model = TCNModel(**model_config)
        state_dict = load_model_state(model_path)
        model.load_state_dict(state_dict)
        
        # Set to inference mode
        model.eval()
        
        # Forward pass
        with torch.no_grad():
            output = model(sample_input)
            
        # Verify output
        assert output is not None
        assert not output.requires_grad
        
    def test_model_parameter_count(self, model_path, model_config):
        """Test model parameter count."""
        # Create and load model
        model = TCNModel(**model_config)
        state_dict = load_model_state(model_path)
        model.load_state_dict(state_dict)
        
        # Count parameters
        total_params = sum(p.numel() for p in model.parameters())
        trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
        
        # Verify parameter counts
        assert total_params > 0
        assert trainable_params > 0
        assert trainable_params <= total_params 